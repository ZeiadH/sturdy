//Directives
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>

//defining constants to make program simpler
#define PAGES 256
#define MASKING 255
#define SIZE_PAGE 256
#define MEMORY_SIZE PAGES * SIZE_PAGE
#define BUFFER 10

//variable declaration for pages
int page[PAGES];
//variable declaration for pointer
signed char* pointer;
//variable declaration 
signed char memory[MEMORY_SIZE];


int main(int argc, const char* argv[])
{
    //If user does not enter the proper amount of arguements then unsuccessful
    if (argc != 3)
    {
        printf("Please enter the files in the following order:' ./a.out BACKING_STORE.bin addresses.txt'.\nAt the end reult will be written into output.txt file.\n");
        exit(0);
    }

    for (int i = 0; i < PAGES; i++)
    {
        page[i] = -1;
    }

    //type int for address total and number of pagefaults, initialized at 0
    int address_total = 0; 
    int pageFault = 0;

    //BACKING_STORE.bin
    const char* fName = argv[1];

    //input file addresses.txt
    const char* fInput = argv[2];
    //output file output.txt
    const char* fOutput = "output.txt";

    //fd for BACKING
    char buff[BUFFER];
    unsigned char freePage=0;
    int fdPtr = open(fName, O_RDONLY);
    pointer = mmap(0, MEMORY_SIZE, PROT_READ, MAP_PRIVATE, fdPtr, 0);
    FILE* input_fp = fopen(fInput, "r");
    FILE* output_fp = fopen(fOutput, "w");
   
    while (fgets(buff, BUFFER, input_fp) != NULL)
    {
        int logical_addr = atoi(buff);
        int offset = logical_addr & 255;
	//8 for number of bits
        int logical = (logical_addr >> 8) & MASKING;
        int physical = page[logical];
        address_total++;

        //determining if pagefault =-1
        if (physical == -1)
        {
            pageFault++;
            physical = freePage;
            freePage++;

            //reading and storing it
            memcpy(memory + physical * SIZE_PAGE, pointer + logical * SIZE_PAGE, SIZE_PAGE);
            page[logical] = physical;
        }

        //storing signed byte at physical address 
        // 8 used for number of bits
        int physicall_addr = (physical <<8) | offset;
        signed char value = memory[physical * SIZE_PAGE + offset];

        // storing in output.txt file
        fprintf(output_fp, "Logical address: %d physical address: %d Value: %d\n", logical_addr, physicall_addr, value);

        //Displaying output
        printf("Logical address: %d physical address: %d Value: %d\n", logical_addr, physicall_addr, value);
    }

    //printing the statistics to output.txt file
    fprintf(output_fp, "Number of translated addresses = %d\nPage faults = %d\nPage fault rate = %.1f % \n", address_total, pageFault, (pageFault / (address_total * 1.)) * 100);

    //Displaying the statisitcs to user
    printf("Number of translated addresses = %d\nPage faults = %d\nPage fault rate = %.1f %\n", address_total, pageFault, (pageFault / (address_total * 1.)) *100);

    //using fclose to close the pointers
    fclose(input_fp);
    fclose(output_fp);

    return 0;
}
